<style>

footer {
    display: flex;
    width: 100%;
    height: 60px;
    background-color: black;
    align-items: center;
    justify-content: center;
    position: fixed;
    bottom: 0;
    left: 0;
    z-index: 1000;
}

.logos {
    width: 40px;
    height: 40px;
    margin: 5px 10px;
}

</style>
<footer>

<a href=""><img class="logos" src="../Imagenes/instagrama.jpg" alt="instagram"></a>
<a href=""><img class="logos" src="../Imagenes/pajaro.jpg" alt="twitter"></a>
<a href=""><img class="logos" src="../Imagenes/tiktoka.jpg" alt="tiktok"></a>

</footer>


</body>
</html>