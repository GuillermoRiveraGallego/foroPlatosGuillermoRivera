<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ForoPlatos</title>
    <link rel="icon" href="../Imagenes/iconoPagina.png" type="image/x-icon">
    <link rel="stylesheet" href="../Vista/css/estilosIndexPrincipal.css">
</head>

<body>
<div class="header-container">
        <header class="header">
            
        <img class="logoHeader" src="../Imagenes/foroLogo5.png" alt="">

        <div class="l">

        <a class="homePerfil" href="../Controlador/index.php">Home</a>
        
        </div>

        </header>
</div>

<style>

.homePerfil{

    margin-right: 20px;

}

</style>