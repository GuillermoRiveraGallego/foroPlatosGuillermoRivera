<?php

include("../Control/sesion.php");
control();

include("../Vista/headerAdministradoresHome.php");
include("../Vista/adminCreaIngrediente.php");
include("../Vista/footer.php");

?>