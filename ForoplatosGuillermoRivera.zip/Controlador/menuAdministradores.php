<?php
include("../Control/sesion.php");
control();


include("../Vista/headerAdministradoresHome.php");

include("../Vista/opcionesDelAdministrador.php");

include("../Vista/footer.php");