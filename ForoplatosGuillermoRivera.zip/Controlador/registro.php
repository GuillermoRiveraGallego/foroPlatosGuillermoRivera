<?php

        include("../Vista/registroLogin.php");

    ?>